#!/bin/bash
# Directorio donde se almacenan los archivos comprimidos
target_directory="/computaciontp1"

# Directorios a comprimir
directories=("/root" "/etc" "/opt" "/var" "/u01" "/u02" "/u03")

# Comprimir los directorios individualmente
for directory in "${directories[@]}"
do
	base_name="$(basename "$directory")"
	tar_file="$target_directory/$base_name.tar.gz"

	tar -czf "$tar_file" "$directory"
	echo "Se ha comprimido el directorio $directory en $tar_file"

	if [ "$directory" = "/var" ]; then
		# Divide el archivo en partes (ya que generalmente pesa demas)
		split -b 70M "$tar_file" "$target_directory/$base_name.part"

		# Eliminar el archivo comprimido original
		rm "$tar_file"
		echo "El archivo comprimido original ha sido dividido en partes"
	fi
done

# Subir al repositorio
read -p "¿Desea subir los archivos al repositorio? (y/n): " answer
if [ "$answer" = "y" ]; then
	# Ejecutar git add .
	cd "$target_directory"
	git add .

    	# Generar el commit
    	read -p "Ingrese un mensaje para el commit: " commit_message git commit -c -m "$commit_message"
	# Realizar git push
    	git push

    	echo "Los archivos han sido subidos al repositorio."
fi
