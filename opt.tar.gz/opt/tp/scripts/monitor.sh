#!/bin/bash
# Verificar la existencia de los procesos
check_process() {
	process_name="$1"
	running=$(pgrep "$process_name")
	if [ -z "$running" ]; then
    		# Si el proceso no se encuentra en ejecucion, envia un mail
    		echo "El proceso $process_name no se encuentra en ejecución." | mailx -s "Alerta de proceso" root
	else
		# El proceso se esta ejecutando
		echo "Proceso: $process_name ok." | mailx -s "Estado del proceso" root
	fi
}
# Verificar procesos
check_process "mariadb_server"
check_process "apache2"
check_process "ssh"
