#!/bin/bash
PROCESS_NAME=$1
RESULT=$(ps aux | grep $PROCESS_NAME | grep -v grep)
if [ -z "$RESULT" ]; then
    echo "$PROCESS_NAME is not running" | mail -s "Process Monitor" root
fi
