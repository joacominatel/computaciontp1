#!/bin/bash 
#Función para mostrar la ayuda
mostrar_ayuda() { 
	echo "Uso: $0 <directorio_origen> <directorio_destino>"
	echo "Descripción: Este script realiza un respaldo de los directorios proporcionados y guarda el respaldo en el directorio destino."
	echo "Argumentos:"
	echo " -h: Muestra esta ayuda"
	exit 0
}

# Verifica si se proporcionó la opción de ayuda
if [ "$1" = "-h" ]; then
	mostrar_ayuda
fi

# Comprueba que se hayan proporcionado los dos argumentos
if [ $# -ne 2 ]; then
	echo "Uso: $0 <directorio_origen> <directorio_destino>"
	exit 1
fi

# Directorios de origen y destino
directorio_origen=$1
directorio_destino=$2

# Verifica y valida el directorio de origen
if [ ! -d "$directorio_origen" ]; then
	echo "El directorio de origen '$directorio_origen' no existe o no está montado."
	exit 1
fi

# Nombre del directorio de origen sin ruta
nombre_directorio=$(basename "$directorio_origen")

# Nombre del archivo de respaldo con el formato solicitado
fecha=$(date +%Y%m%d) archivo_respaldo="${nombre_directorio}_bkp_${fecha}.tar.gz"

# Ruta completa del archivo de respaldo
ruta_respaldo="${directorio_destino}/${archivo_respaldo}"

# Realiza el respaldo
tar -czvf "$ruta_respaldo" "$directorio_origen" > /dev/null

# Verifica si el respaldo se creó correctamente
if [ $? -eq 0 ]; then
	echo "Respaldo exitoso: $ruta_respaldo"
else
	echo "Error al crear el respaldo."
	exit 1
fi

# Crea el mensaje para el log
mensaje_log="Respaldo exitoso: $ruta_respaldo"

# Obtiene la hora actual
hora_actual=$(date "+%Y-%m-%d %H:%M:%S")

# Guarda el mensaje en el log
echo "[$hora_actual] $mensaje_log" >> backup.log

# Envía el log por correo electrónico al root usando mailx
echo "$mensaje_log" | mailx -s "Registro de respaldo" root@example.com
