if [ ! -d "/etc" ]; then 
#|| ! mountpoint -q "/etc"; then
	echo "No existe"
	exit 1
fi

echo "Existe"
